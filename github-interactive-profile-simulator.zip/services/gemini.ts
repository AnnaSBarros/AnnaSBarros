
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Initialize the Gemini API client directly using the environment variable string as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateProjectDescription = async (projectName: string) => {
  try {
    // Generate a response from the model using the recommended gemini-3-flash-preview for text tasks.
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Create a professional 1-sentence description for a GitHub project named "${projectName}". Focus on technical value for LinkedIn.`,
    });
    // Extract text output using the .text property from the GenerateContentResponse object.
    return response.text || "A sophisticated technical project pushing the boundaries of software engineering.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "A high-performance repository focusing on clean code and scalable architecture.";
  }
};
