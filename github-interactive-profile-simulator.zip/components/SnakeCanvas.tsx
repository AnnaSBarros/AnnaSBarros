
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Snake, Star, Point } from '../types';

const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 400;
const SNAKE_COUNT = 3;
const SEGMENT_DISTANCE = 5;
const STAR_COUNT = 15;
const INITIAL_SNAKE_LENGTH = 12;

const SnakeCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [snakes, setSnakes] = useState<Snake[]>([]);
  const [stars, setStars] = useState<Star[]>([]);
  const requestRef = useRef<number | undefined>(undefined);

  const initGame = useCallback(() => {
    // Initialize 3 Snakes
    const newSnakes: Snake[] = Array.from({ length: SNAKE_COUNT }).map((_, i) => ({
      id: `snake-${i}`,
      segments: Array.from({ length: INITIAL_SNAKE_LENGTH }).map(() => ({ 
        x: Math.random() * CANVAS_WIDTH, 
        y: Math.random() * CANVAS_HEIGHT 
      })),
      color: i === 0 ? '#238636' : '#30363d', // One green, two grey
      speed: 1.5 + Math.random() * 1.5,
      angle: Math.random() * Math.PI * 2,
      size: 7,
    }));

    // Initialize Stars (The food)
    const newStars: Star[] = Array.from({ length: STAR_COUNT }).map(() => ({
      x: Math.random() * CANVAS_WIDTH,
      y: Math.random() * CANVAS_HEIGHT,
      vx: (Math.random() - 0.5) * 2, // Slow drifting
      vy: (Math.random() - 0.5) * 2,
      radius: 4,
    }));

    setSnakes(newSnakes);
    setStars(newStars);
  }, []);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const update = useCallback(() => {
    // 1. Update Stars position (drifting)
    setStars(prevStars => prevStars.map(star => {
      let nx = (star.x + star.vx + CANVAS_WIDTH) % CANVAS_WIDTH;
      let ny = (star.y + star.vy + CANVAS_HEIGHT) % CANVAS_HEIGHT;
      return { ...star, x: nx, y: ny };
    }));

    // 2. Update Snakes and check for eating
    setSnakes(prevSnakes => {
      return prevSnakes.map(snake => {
        const head = snake.segments[0];
        
        // Find nearest star to target
        let nearestStarIdx = -1;
        let minDist = 300;
        stars.forEach((star, idx) => {
          const dx = star.x - head.x;
          const dy = star.y - head.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < minDist) {
            minDist = d;
            nearestStarIdx = idx;
          }
        });

        let targetAngle = snake.angle;
        if (nearestStarIdx !== -1) {
          const target = stars[nearestStarIdx];
          targetAngle = Math.atan2(target.y - head.y, target.x - head.x);
        } else {
          // Random wander if no stars nearby
          if (Math.random() < 0.05) targetAngle += (Math.random() - 0.5) * 0.5;
        }

        // Smooth steering
        let angleDiff = targetAngle - snake.angle;
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        const newAngle = snake.angle + angleDiff * 0.1;

        const newHead = {
          x: (head.x + Math.cos(newAngle) * snake.speed + CANVAS_WIDTH) % CANVAS_WIDTH,
          y: (head.y + Math.sin(newAngle) * snake.speed + CANVAS_HEIGHT) % CANVAS_HEIGHT,
        };

        let newSegments = [newHead, ...snake.segments.slice(0, -1)];

        // Handle trailing segments logic
        for (let i = 1; i < newSegments.length; i++) {
          const prev = newSegments[i-1];
          const curr = newSegments[i];
          const dx = prev.x - curr.x;
          const dy = prev.y - curr.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > SEGMENT_DISTANCE) {
            const ratio = SEGMENT_DISTANCE / dist;
            newSegments[i] = {
              x: prev.x - dx * ratio,
              y: prev.y - dy * ratio,
            };
          }
        }

        // Collision detection with stars
        let eaten = false;
        setStars(currentStars => {
          const updated = [...currentStars];
          updated.forEach((star, idx) => {
            const dx = star.x - newHead.x;
            const dy = star.y - newHead.y;
            const d = Math.sqrt(dx * dx + dy * dy);
            if (d < 15) { // Eating range
              eaten = true;
              updated[idx] = {
                ...star,
                x: Math.random() * CANVAS_WIDTH,
                y: Math.random() * CANVAS_HEIGHT
              };
            }
          });
          return updated;
        });

        // If eaten, add a segment to "revive/grow"
        if (eaten) {
          const last = newSegments[newSegments.length - 1];
          newSegments.push({ ...last });
        }

        return { ...snake, segments: newSegments, angle: newAngle };
      });
    });

    requestRef.current = requestAnimationFrame(update);
  }, [stars]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [update]);

  // Render to canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Grid Background
    ctx.strokeStyle = '#161b22';
    ctx.lineWidth = 1;
    for (let x = 0; x < CANVAS_WIDTH; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, CANVAS_HEIGHT); ctx.stroke();
    }
    for (let y = 0; y < CANVAS_HEIGHT; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CANVAS_WIDTH, y); ctx.stroke();
    }

    // Draw Stars (Food)
    stars.forEach(star => {
      ctx.fillStyle = '#e3b341';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#e3b341';
      ctx.beginPath();
      // Draw as a small diamond/star shape
      ctx.moveTo(star.x, star.y - star.radius);
      ctx.lineTo(star.x + star.radius/2, star.y - star.radius/2);
      ctx.lineTo(star.x + star.radius, star.y);
      ctx.lineTo(star.x + star.radius/2, star.y + star.radius/2);
      ctx.lineTo(star.x, star.y + star.radius);
      ctx.lineTo(star.x - star.radius/2, star.y + star.radius/2);
      ctx.lineTo(star.x - star.radius, star.y);
      ctx.lineTo(star.x - star.radius/2, star.y - star.radius/2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });

    // Draw Snakes
    snakes.forEach(snake => {
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = snake.size * 2;
      ctx.strokeStyle = snake.color;
      
      snake.segments.forEach((seg, idx) => {
        if (idx === 0) ctx.moveTo(seg.x, seg.y);
        else ctx.lineTo(seg.x, seg.y);
      });
      ctx.stroke();

      // Eyes on the head
      const head = snake.segments[0];
      ctx.fillStyle = 'white';
      const eyeOffset = 4;
      const eyeX1 = head.x + Math.cos(snake.angle + 0.5) * eyeOffset;
      const eyeY1 = head.y + Math.sin(snake.angle + 0.5) * eyeOffset;
      const eyeX2 = head.x + Math.cos(snake.angle - 0.5) * eyeOffset;
      const eyeY2 = head.y + Math.sin(snake.angle - 0.5) * eyeOffset;
      ctx.beginPath(); ctx.arc(eyeX1, eyeY1, 2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(eyeX2, eyeY2, 2, 0, Math.PI * 2); ctx.fill();
    });
  }, [snakes, stars]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-[#30363d] bg-[#0d1117] p-4 shadow-inner">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-sm font-semibold text-[#8b949e] flex items-center gap-2">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16"><path d="M1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8Zm15 0A8 8 0 1 0 0 8a8 8 0 0 0 16 0ZM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3Z"></path></svg>
          Commit Star Pursuit (3 Snakes)
        </h3>
        <div className="flex gap-4 text-xs text-[#8b949e]">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#238636]"></span> You</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#30363d]"></span> Others</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#e3b341]"></span> Stars (Eat to Revive)</span>
        </div>
      </div>
      <canvas 
        ref={canvasRef} 
        width={CANVAS_WIDTH} 
        height={CANVAS_HEIGHT} 
        className="w-full h-auto cursor-crosshair rounded-lg"
      />
      <div className="absolute bottom-6 right-6 bg-[#161b22] px-3 py-1 rounded-full text-[10px] text-[#8b949e] border border-[#30363d]">
        Goal: Eat the stars to grow and maintain your streak!
      </div>
    </div>
  );
};

export default SnakeCanvas;
