
import React, { useEffect, useState } from 'react';
import { Repository } from '../types';
import { generateProjectDescription } from '../services/gemini';

const RepoCard: React.FC<{ repo: Repository }> = ({ repo }) => {
  const [description, setDescription] = useState(repo.description);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchAIBio = async () => {
      setIsLoading(true);
      const res = await generateProjectDescription(repo.name);
      setDescription(res);
      setIsLoading(false);
    };
    if (!repo.description || repo.description === "Loading AI insights...") {
      fetchAIBio();
    }
  }, [repo.name]);

  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded-lg p-5 hover:border-[#388bfd] transition-colors group flex flex-col h-full cursor-pointer">
      <div className="flex justify-between items-start mb-2">
        <h4 className="text-[#58a6ff] font-semibold text-lg group-hover:underline">
          {repo.name}
        </h4>
        <div className="text-[#8b949e] border border-[#30363d] px-2 py-0.5 rounded-full text-[10px] font-medium">
          Public
        </div>
      </div>
      
      <p className="text-[#8b949e] text-sm mb-4 flex-grow italic">
        {isLoading ? "Generating professional description with Gemini..." : description}
      </p>
      
      <div className="flex items-center gap-4 text-xs text-[#8b949e]">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-[#3178c6]"></span>
          <span>{repo.languages[0]}</span>
        </div>
        <div className="flex items-center gap-1">
          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 16 16"><path d="M8 .25a.75.75 0 0 1 .673.418l1.882 3.815 4.21.612a.75.75 0 0 1 .416 1.279l-3.046 2.97.719 4.192a.75.75 0 0 1-1.088.791L8 12.347l-3.766 1.98a.75.75 0 0 1-1.088-.79l.72-4.194L.818 6.374a.75.75 0 0 1 .416-1.28l4.21-.611L7.327.668A.75.75 0 0 1 8 .25Z"></path></svg>
          {repo.stars}
        </div>
        <div>Updated {repo.updatedAt}</div>
      </div>
    </div>
  );
};

export default RepoCard;
