
import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Sector } from 'recharts';
import { Language, GithubStats } from '../types';

const LANGUAGES: Language[] = [
  { name: 'TypeScript', percentage: 45, color: '#3178c6' },
  { name: 'JavaScript', percentage: 25, color: '#f1e05a' },
  { name: 'React', percentage: 15, color: '#61dafb' },
  { name: 'Python', percentage: 10, color: '#3572A5' },
  { name: 'CSS', percentage: 5, color: '#563d7c' },
];

const GITHUB_STATS: GithubStats = {
  totalCommits: 1284,
  totalPRs: 85,
  totalIssues: 42,
  totalStars: 256,
};

const renderActiveShape = (props: any) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill} className="text-sm font-bold">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#8b949e" fontSize={12}>{`${value}%`}</text>
    </g>
  );
};

const StatsSection: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
      {/* GitHub Stats Card */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-6 transition-all hover:border-[#8b949e]">
        <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
          <svg className="w-5 h-5 text-[#8b949e]" fill="currentColor" viewBox="0 0 16 16"><path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8Zm7.5-5a.5.5 0 0 0-1 0v4.5H4a.5.5 0 0 0 0 1h4a.5.5 0 0 0 .5-.5V3Z"></path></svg>
          AnnaSBarros's GitHub Stats
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-[#161b22] rounded-lg">
            <div className="text-[#8b949e] text-xs uppercase tracking-wider mb-1">Total Commits</div>
            <div className="text-2xl font-bold text-white">{GITHUB_STATS.totalCommits}</div>
          </div>
          <div className="p-4 bg-[#161b22] rounded-lg">
            <div className="text-[#8b949e] text-xs uppercase tracking-wider mb-1">Total PRs</div>
            <div className="text-2xl font-bold text-white">{GITHUB_STATS.totalPRs}</div>
          </div>
          <div className="p-4 bg-[#161b22] rounded-lg">
            <div className="text-[#8b949e] text-xs uppercase tracking-wider mb-1">Total Issues</div>
            <div className="text-2xl font-bold text-white">{GITHUB_STATS.totalIssues}</div>
          </div>
          <div className="p-4 bg-[#161b22] rounded-lg">
            <div className="text-[#8b949e] text-xs uppercase tracking-wider mb-1">Total Stars</div>
            <div className="text-2xl font-bold text-white">{GITHUB_STATS.totalStars}</div>
          </div>
        </div>
      </div>

      {/* Languages Card */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-6 transition-all hover:border-[#8b949e]">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <svg className="w-5 h-5 text-[#8b949e]" fill="currentColor" viewBox="0 0 16 16"><path d="M4.176 9.032a.5.5 0 0 0-.656.327l-.5 1.7a.5.5 0 0 0 .961.278l.5-1.7a.5.5 0 0 0-.305-.605ZM6.34 10.268a.5.5 0 0 1 .155.67l-.8 1.4a.5.5 0 1 1-.87-.5l.8-1.4a.5.5 0 0 1 .715-.17ZM9.66 10.268a.5.5 0 0 0-.155.67l.8 1.4a.5.5 0 1 0 .87-.5l-.8-1.4a.5.5 0 0 0-.715-.17ZM12.48 9.032a.5.5 0 0 1 .656.327l.5 1.7a.5.5 0 1 1-.961.278l-.5-1.7a.5.5 0 0 1 .305-.605ZM8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1Zm0 13a6 6 0 1 1 0-12 6 6 0 0 1 0 12Z"></path></svg>
          Most Used Languages
        </h3>
        <div className="h-[250px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                activeIndex={activeIndex}
                activeShape={renderActiveShape}
                data={LANGUAGES}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                dataKey="percentage"
                onMouseEnter={onPieEnter}
              >
                {LANGUAGES.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#161b22', border: '1px solid #30363d', borderRadius: '8px' }}
                itemStyle={{ color: '#c9d1d9' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default StatsSection;
