
export interface GithubStats {
  totalCommits: number;
  totalPRs: number;
  totalIssues: number;
  totalStars: number;
}

export interface Language {
  name: string;
  percentage: number;
  color: string;
}

export interface Repository {
  name: string;
  description: string;
  languages: string[];
  stars: number;
  forks: number;
  updatedAt: string;
}

export interface Point {
  x: number;
  y: number;
}

export interface SnakeSegment extends Point {}

export interface Snake {
  segments: SnakeSegment[];
  color: string;
  speed: number;
  angle: number;
  size: number;
  id: string;
}

export interface Star extends Point {
  vx: number;
  vy: number;
  radius: number;
}

export interface CommitDot extends Point {
  value: number;
}
