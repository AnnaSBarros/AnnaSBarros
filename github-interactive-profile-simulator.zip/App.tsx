
import React from 'react';
import SnakeCanvas from './components/SnakeCanvas';
import StatsSection from './components/StatsSection';
import RepoCard from './components/RepoCard';
import { Repository } from './types';

const REPOS: Repository[] = [
  {
    name: 'quantum-core-engine',
    description: 'Loading AI insights...',
    languages: ['TypeScript', 'Rust'],
    stars: 142,
    forks: 24,
    updatedAt: '2 days ago'
  },
  {
    name: 'neuro-vision-ui',
    description: 'Loading AI insights...',
    languages: ['React', 'D3.js'],
    stars: 89,
    forks: 12,
    updatedAt: '1 week ago'
  }
];

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0d1117] text-[#c9d1d9] pb-20">
      {/* Navbar Placeholder */}
      <nav className="border-b border-[#30363d] bg-[#161b22] px-4 py-3 mb-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <svg height="32" viewBox="0 0 16 16" width="32" className="text-white fill-current"><path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path></svg>
            <span className="font-semibold text-white">AnnaSBarros</span>
          </div>
          <div className="hidden md:flex gap-4 text-sm font-medium">
            <a href="#" className="hover:text-white">Overview</a>
            <a href="#" className="hover:text-white border-b-2 border-[#f78166] pb-1">Repositories</a>
            <a href="#" className="hover:text-white">Projects</a>
            <a href="#" className="hover:text-white">Packages</a>
          </div>
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 border border-[#30363d]"></div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="mb-6">
            <div className="w-64 h-64 rounded-full border border-[#30363d] bg-[#161b22] mb-4 overflow-hidden">
               <img src="https://picsum.photos/seed/anna/300/300" alt="Profile" className="w-full h-full object-cover" />
            </div>
            <h1 className="text-2xl font-bold text-white leading-tight">Anna S. Barros</h1>
            <h2 className="text-[#8b949e] text-xl font-light mb-4">AnnaSBarros</h2>
            <button className="w-full py-1.5 px-4 bg-[#21262d] border border-[#30363d] rounded-md text-sm font-medium hover:bg-[#30363d] transition-colors mb-4">
              Edit profile
            </button>
            <p className="text-sm text-[#c9d1d9] mb-4">
              ✨ Exploring the intersection of AI, React, and Creative Coding. Building scalable solutions with a focus on UI/UX. 🚀
            </p>
            <div className="flex flex-col gap-2 text-sm text-[#8b949e]">
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16"><path d="M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM7 3a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z"></path><path d="M11 11.5a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2a.5.5 0 0 1 .5-.5Zm-6 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2a.5.5 0 0 1 .5-.5ZM13.02 2.81a.5.5 0 0 1 .47.674l-3.94 11.458a.5.5 0 0 1-.945 0L4.665 3.484a.5.5 0 0 1 .47-.674h7.885ZM12.07 3.81H5.93l3.07 8.927 3.07-8.927Z"></path></svg>
                <span>Curitiba, Brazil</span>
              </div>
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 16 16"><path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0Zm10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM8 10a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"></path><path d="M2 3a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H2Zm12 1a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h12Z"></path></svg>
                <a href="https://linkedin.com/in/AnnaSBarros" className="hover:text-[#58a6ff]">linkedin.com/in/AnnaSBarros</a>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-8">
          {/* README Style Header */}
          <section className="bg-[#0d1117] border border-[#30363d] rounded-lg p-6">
             <div className="prose prose-invert max-w-none">
                <h3 className="text-[#8b949e] text-xs font-semibold uppercase mb-4">AnnaSBarros / README.md</h3>
                <h1 className="text-3xl font-bold mb-6">Hello World, I'm Anna! 👋</h1>
                <SnakeCanvas />
             </div>
          </section>

          {/* Stats & Languages */}
          <section>
            <h2 className="text-lg font-semibold mb-4 text-[#f0f6fc]">Performance Metrics</h2>
            <StatsSection />
          </section>

          {/* Project Showcase for LinkedIn */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-[#f0f6fc]">Top Repositories</h2>
              <span className="text-xs text-[#8b949e] bg-[#161b22] px-2 py-1 rounded border border-[#30363d]">Optimized for LinkedIn</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {REPOS.map((repo, i) => (
                <RepoCard key={i} repo={repo} />
              ))}
            </div>
          </section>

          {/* Social Proof */}
          <footer className="pt-10 border-t border-[#30363d] text-center text-[#8b949e] text-sm">
             <p>© 2024 AnnaSBarros. Built with React, Tailwind and Gemini AI.</p>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default App;
